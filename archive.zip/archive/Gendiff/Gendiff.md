Gendiff

- Download the executable to your computer
- Create a directory called "Gendiff" in your "Program Files" directory on your C: drive and copy the gendiff application to the folder. Also put a copy of the gen files you wish to compare in the directory.
- Run a command line interface via the "Run" command in the Start menu.
- At the prompt, type cd c:\Program Files\Gendiff\ and hit "return".
- Again, at the prompt, type "gendiff" to see the syntax that should be used.
- You can copy and paste long filenames by selecting the file, clicking once so the text is selected and right-clicking for a popup menu. 
 
- Hit "return" to see the results displayed on screen, Alternatively, type "> output.txt" after the second gen filename, and hit return to write the results to a text file.
