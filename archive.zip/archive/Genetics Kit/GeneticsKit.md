*Important: You must have Docking Station installed to use this product. Enter the following case-sensitive username and license key:*
Gameware
500-4892W-1234U-WE
