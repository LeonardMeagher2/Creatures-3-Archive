*Monitor window:* Choose View|Monitor to turn on the text console monitor. In the game, use the commands DBG: OUTV and DBG: OUTS to send data to that window. This is very useful for debugging agents - you can make them print output saying what they are doing.

*Debug menu/toolbar:* This lets you pause and single step the whole game. Driving the game from the debugger means that instead of using its own internal ticks, the debugger will make the game tick. This guarantees that all debugger windows are updated every tick, rather than polled occasionally as they would otherwise be.

*Agent menu:* The main part of the debugger window shows all the agents in the world at the moment. They are organised in a tree view by classifier. The last node is the unique id (see UNID and AGNT commands) of the agent. You can select that, and then choose options on the Agent menu to act on it. Double click on an agent to open a watch window on it.

*Global/hot watch windows:* These can be opened from the Watch menu. The global watch window is used for viewing variables and data not specific to one agent. The hot watch window uses the HOTS command to let you view variables and data for the agent the hand is currently pointing at.

*Watch windows:* All watch Windows work the same. You can right click to add or edit the watches. Each watch is simply a chunk of CAOS code which is executed periodically. Use the OUTV and OUTS commands to print data to the watch output field.

*Agent watch windows:* When watching an agent, a source code view is shown on the right hand side of the watch window. If the agent is in a script the code is displayed, with the next line to run highlighted. Each agent runs at least 5 instructions per tick, or more if in an INST. This makes it quite hard to see what is going on when single stepping the game tick by tick. For more detail, right click and choose Follow agent's code. The whole game will pause next time that agent runs a script, and you can single step through the script, using the toolbar buttons on the main debug window.

*Customization:* You will see some files with names like 0.0.0.always.txt and Creatures 3/global.optional.txt. These let you customise a set of default watch variables, and a set which appear in the watch window right button context menu. You can make new customisation files following the pattern G/X.Y.txt, and you can edit the existing ones.

global watches appear in the global watch window. Those named after a classifier appear when debugging agents of that classifier - for example 0.0.0 will make the watch appear for all agents, 4.0.0 would be for all Creatures.

always watches appear in a watch window immediately, whereas optional ones appear in the context menu for you to add.

Files in the same folder as the debugger executable appear for all games, those in a sub folder named after the game will appear only for that game. You may want a Docking Station and a Creatures 3 folder.

If you make a cool set of files with lots of watches, do post them for others in the CDN news group!

*Known bug:* If you move the splitter bar in the middle of an agent watch window, the CAOS debugger often crashes.
